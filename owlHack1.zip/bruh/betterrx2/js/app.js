

/* SOME CONSTANTS */


/* SUPPORTING FUNCTIONS */


//document ready section
$(document).ready(function (){

    /* ----------------- start up navigation -----------------*/	
    /* controls what gets revealed when the page is ready     */

    /* ------------------  basic navigation -----------------*/	
    /* this controls navigation - show / hide pages as needed */

	$("#div-start").show()
    $("#about").show();
    $("#map").hide();
    $("#pagebr").hide();
    $.ajax({
        url: "http://ec2-52-206-85-110.compute-1.amazonaws.com:8203/mednames",
        method: "GET",
        data: "",
        success: function(data){

            for (row = 0; row < data.length ; row++){
                let medication_name = data[row].medication_name;
                let presId = data[row].pres_id;
                console.log(medication_name)
                $("#medication_name").append("<option value=" + presId +">" + medication_name + "</option>");
            }            
        },
        error:function(error){
            console.log(error);
        }
    })

    $.ajax({
        url: "http://ec2-52-206-85-110.compute-1.amazonaws.com:8203/pharmnames",
        method: "GET",
        data: "",
        success: function(data){

            for (row = 0; row < data.length ; row++){
                let pharmacy_name = data[row].name;
                console.log(medication_name)
                $("#pharmFilter").append("<option value=" + pharmacy_name +">" + pharmacy_name + "</option>");
            }            
        },
        error:function(error){
            console.log(error);
        }
    })

    let array = [];
    $('#search_button').click( () => {
        $("#message-error").html("")
        $("#message-error").removeClass()
        var selected_medication = $("#medication_name").val();
        var pharmFilter = $("#pharmFilter").val();
        if (selected_medication == null){
            $("#message-error").html("Please select your medication")
            $("#message-error").addClass("alert alert-danger")
        } else {
            
            if (pharmFilter == ""){
        console.log(selected_medication);
        $.ajax({
        url: "http://ec2-52-206-85-110.compute-1.amazonaws.com:8203/medinfo",
        method: "GET",
        data: "presId=" + selected_medication,
        success: function(data){
            console.log(data);
            array = [];
            for (i = 0 ; i < data.length ; i++){
                let image = ""
                if (data[i].name == "CVS"){
                    image = "images/CVS-Symbol.png"
                }
                if (data[i].name == "RiteAid"){
                    image = "images/rideAid.png"
                }
                if (data[i].name == "Walgreens"){
                    image = "images/Walgreens-Logo.png"
                }
                if (data[i].name == "ACME "){
                    image = "images/ACME-logo.png"
                }
                if (data[i].name == "Walmart"){
                    image = "images/Walmart-Logo.wine.png"
                }
                if (data[i].name == "ShopRite"){
                    image = "images/shopRite.png"
                }

                array.push([])
                array[i].push("<img src=" + image +" style='height: 50px;'><br>"+data[i].name + "<br>" + data[i].address + "<br>" + "<b>Price: </b>$" + data[i].price + "<br> <a href='https://www.google.com/maps/dir/?api=1&destination=" + data[i].address + "&travelmode=driving' target='_blank'>Get Directions</a>")
                array[i].push(data[i].lat)
                array[i].push(data[i].long) 
            }
            console.log(array)
            initMap()
            $("#about").hide();
            $("#map").show();
            $("#pagebr").show();
            
        },
        error:function(error){
            console.log(error);
        }
    })
    } else {
        console.log(selected_medication);
        $.ajax({
        url: "http://ec2-52-206-85-110.compute-1.amazonaws.com:8203/medinfofilter",
        method: "GET",
        data: "presId=" + selected_medication + "&pharmFilter=" + pharmFilter,
        success: function(data){
            console.log(data);
            array = [];
            for (i = 0 ; i < data.length ; i++){
                let image = ""
                if (data[i].name == "CVS"){
                    image = "images/CVS-Symbol.png"
                }
                if (data[i].name == "RiteAid"){
                    image = "images/rideAid.png"
                }
                if (data[i].name == "Walgreens"){
                    image = "images/Walgreens-Logo.png"
                }
                if (data[i].name == "ACME "){
                    image = "images/ACME-logo.png"
                }
                if (data[i].name == "Walmart"){
                    image = "images/Walmart-Logo.wine.png"
                }
                if (data[i].name == "ShopRite"){
                    image = "images/shopRite.png"
                }

                array.push([])
                array[i].push("<img src=" + image +" style='height: 50px;'><br>"+data[i].name + "<br>" + data[i].address + "<br>" + "<b>Price: </b>$" + data[i].price + "<br> <a href='https://www.google.com/maps/dir/?api=1&destination=" + data[i].address + "&travelmode=driving' target='_blank'>Get Directions</a>")
                array[i].push(data[i].lat)
                array[i].push(data[i].long) 
            }
            console.log(array)
            initMap()
            $("#about").hide();
            $("#map").show();
            $("#pagebr").show();
            
        },
        error:function(error){
            console.log(error);
        }
    })        
    }

        }
    });

    function initMap() {
    var center = {lat: 39.98, lng: -75.16};
    var locations = array;
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: center
    });
    var infowindow =  new google.maps.InfoWindow({});
    var marker, count;

    //loop through every location and mark it on map 


    for (count = 0; count < locations.length; count++) {
        marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[count][1], locations[count][2]),
        map: map,
        title: locations[count][0]
        });
        
    google.maps.event.addListener(marker, 'click', (function (marker, count) {
        return function () {
            infowindow.setContent(locations[count][0]);
            infowindow.open(map, marker);
        }
        })(marker, count));
    }
    }

    window.initMap = initMap;


}); /* end the document ready event*/