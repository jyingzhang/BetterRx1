
//all data manipulation happens within initMap()
let medData = 0;
let locations = '['
for (row = 0; row < medData.length ; row++){
    locations += '[';
    locations += medData[row]['name'];
    locations += "<br>";
    locations += medData[row]['address']+"<br";
}