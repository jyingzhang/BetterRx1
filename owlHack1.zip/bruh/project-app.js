let express = require('express'); //import express, because I want easier management of GET and POST requests.  
//let fs = require('fs');  //fs is used to manipulate the file system
let MySql = require('sync-mysql');  //MySql is used to manipulate a database connection
const axios = require('axios');
"use strict";

//set up the database connection 
const options = {
  user: 'mis51',
  password: 'B8YE52',
  database: 'mis51blue',
  host: 'dataanalytics.temple.edu'
};

// create the database connection
const connection = new MySql(options);

let app = express();  //the express method returns an instance of a app object
app.use(express.urlencoded({extended:false}));  //use this because incoming data is urlencoded

app.use(function(req, res, next) {
    express.urlencoded({extended:false})
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
    next();  //go process the next matching condition
  });

//supporting functions *******************************************************************

let getMedNames = function(res){
    try{
        let txtSQL = "SELECT medication_name, pres_id FROM prescriptions";
        let results = connection.query(txtSQL);
        responseWrite(res, results, 200);
        return;
    } catch(e){
        console.log(e);
        responseWrite(res, "Unexpected Error (getMedNames)", 500);
        return;
    }
}

let getPharmNames = function(res){
    try{
        let txtSQL = "SELECT DISTINCT name FROM pharmacies";
        let results = connection.query(txtSQL);
        responseWrite(res, results, 200);
        return;
    } catch(e){
        console.log(e);
        responseWrite(res, "Unexpected Error (getPharmNames)", 500);
        return;
    }
}

let medInfo = function(res, presId){
    try{
        let txtSQL = "SELECT pharmacies.name, pharmacies.address, pharmacies.long, pharmacies.lat, pharm_pres.price FROM pharmacies JOIN pharm_pres ON pharmacies.pharm_id = pharm_pres.pharm_id JOIN prescriptions ON pharm_pres.pres_id = prescriptions.pres_id WHERE prescriptions.pres_id = ?";
        let results = connection.query(txtSQL,[presId]);
        responseWrite(res, results, 200);
        return;
    } catch(e){
        console.log(e);
        responseWrite(res, "Unexpected Error (medInfo)", 500);
        return;
    }
}

let medInfoFilter = function(res, presId, pharmFilter){
    try{
        let txtSQL = "SELECT pharmacies.name, pharmacies.address, pharmacies.long, pharmacies.lat, pharm_pres.price FROM pharmacies JOIN pharm_pres ON pharmacies.pharm_id = pharm_pres.pharm_id JOIN prescriptions ON pharm_pres.pres_id = prescriptions.pres_id WHERE prescriptions.pres_id = ? AND pharmacies.name = ?";
        let results = connection.query(txtSQL,[presId, pharmFilter]);
        responseWrite(res, results, 200);
        return;
    } catch(e){
        console.log(e);
        responseWrite(res, "Unexpected Error (medInfoFilter)", 500);
        return;
    }
}

//responseWrite is a supporting function.  It sends 
// output to the API consumer and ends the response.
// This is hard-coded to always send a json response.
let responseWrite = function(res,Output,responseStatus){
    res.writeHead(responseStatus, {'Content-Type': 'application/json'});
    res.write(JSON.stringify(Output));
    res.end();
};

//error trapping ************************************************************************

app.get("/mednames", function(req,res,next){
    next();
})

app.get("/pharmnames", function(req,res,next){
    next();
})

app.get("/medinfo", function(req,res,next){
    let presId = req.query.presId
    if(presId == "" || presId == undefined || isNaN(presId)){
        responseWrite(res, "The medicine was missing or incorrect",400);
        return;
    }
    next();
})

app.get("/medinfofilter", function(req,res,next){
    let pharmFilter = req.query.pharmFilter
    let presId = req.query.presId
    if(pharmFilter == "" || pharmFilter == undefined){
        responseWrite(res, "The presId was missing or incorrect",400);
        return;
    }
    if(presId == "" || presId == undefined || isNaN(presId)){
        responseWrite(res, "The pharmFilter was missing or incorrect",400);
        return;
    }
    next();
})

//event handlers ************************************************************************

app.get("/mednames", function(req,res){
    getMedNames(res)
})

app.get("/pharmnames", function(req,res){
    getPharmNames(res)
})

app.get("/medinfo", function(req,res){
    let presId = req.query.presId
    medInfo(res, presId)
})

app.get("/medinfofilter", function(req,res){
    let pharmFilter = req.query.pharmFilter
    let presId = req.query.presId
    medInfoFilter(res, presId, pharmFilter)
})

//what the app should do when it received a "GET" against the root
app.get('/', function(req, res) {
    //what to do if request has no route ... show instructions
    let message = [];
    
    message[message.length] = "Issue a GET against ./mednames to get the names of the available medicine.";
    message[message.length] = "Issue a GET against ./medinfo with presId to get the pharmacy names, addresses, prices of the desired medicine, longitude and latitude.";
    message[message.length] = "Issue a GET against ./medinfofilter with presId and pharmFilter to get the desired pharmacies, addresses, prices of the desired medicine, longitude and latitude.";


	responseWrite(res,message,200);
    return
});
  
//This piece of code creates the server  
//and listens for requests on a specific port
//we are also generating a message once the 
//server is created
let server = app.listen(8203, "0.0.0.0" ,function(){
    let host = server.address().address;
    let port = server.address().port;
    console.log("The endpoint server is listening on port:" + port);
});